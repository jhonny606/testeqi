package com.jhonnyffer.mycalculadoran;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText edtValor1, edtValor2;
    Button btnSoma, btnSub, btnMulti, btnDiv;
    TextView txtResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //mapeamento dos objetos na classe R
        edtValor1 = findViewById(R.id.edtValor1);
        edtValor2 = findViewById(R.id.edtValor2);
        btnSoma = findViewById(R.id.btnSoma);
        btnSub = findViewById(R.id.btnSub);
        btnMulti = findViewById(R.id.btnMulti);
        btnDiv = findViewById(R.id.btnDiv);
        txtResultado = findViewById(R.id.txtResultado);

        //configurações da Lógica do app, dos Listener + eventos
        btnSoma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int v1 = Integer.parseInt(edtValor1.getText().toString());
                int v2 = Integer.parseInt(edtValor2.getText().toString());
                int resultado = v1 + v2;

                txtResultado.setText(resultado + "");
            }
        });

        btnSub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int v1 = Integer.parseInt(edtValor1.getText().toString());
                int v2 = Integer.parseInt(edtValor2.getText().toString());
                int resultado = v1 - v2;

                txtResultado.setText(resultado + "");
            }
        });

        btnMulti.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int v1 = Integer.parseInt(edtValor1.getText().toString());
                int v2 = Integer.parseInt(edtValor2.getText().toString());
                int resultado = v1 * v2;

                txtResultado.setText(resultado + "");
            }
        });

        btnDiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int v1 = Integer.parseInt(edtValor1.getText().toString());
                int v2 = Integer.parseInt(edtValor2.getText().toString());


                //try é usado para possíveis erros de cálculo para serem corrigidos.
                // Nesse caso, o erro seria convertido para 0.
                int resultado;
                try {
                    resultado = v1 / v2;
                }catch (Exception e) {
                    resultado = 0;
                }

                txtResultado.setText(resultado + "");
            }
        });


    }
}