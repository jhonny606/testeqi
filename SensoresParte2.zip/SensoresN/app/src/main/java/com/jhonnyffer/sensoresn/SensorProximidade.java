package com.jhonnyffer.sensoresn;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SensorProximidade extends AppCompatActivity implements SensorEventListener {
    private TextView resposta;
    private Sensor proximidade;
    private SensorManager medir;
    private Button btnVoltar1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor_proximidade);

        //Mapeamento de todos os objetos da classe R
        medir = (SensorManager) this.getSystemService(SENSOR_SERVICE);
        proximidade = medir.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        resposta = findViewById(R.id.resposta4);
        btnVoltar1 = findViewById(R.id.btnVoltar2);

        btnVoltar1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirVoltar();
            }
        });

    }

    //Chamada de callbacks, que têm a função de definir o comportamento do ciclo de vida
    //das activities
    //onResume e onPause
    @Override
    protected void onResume() {
        medir.registerListener(this, proximidade, SensorManager.SENSOR_DELAY_NORMAL);
        super.onResume();
    }

    @Override
    protected void onPause() {
        medir.unregisterListener(this, proximidade);
        super.onPause();
    }

    //Métodos de abertura de activities

    public void abrirVoltar(){
        Intent janela2 = new Intent(this, MainActivity.class);
        startActivity(janela2);
    }

    //método onSensorChanged: que ocorre quando é executado ou modificado algum tipo de evento
    //relacionado ao sensor especificado
    //se o valor do evento for = a zero, é pq estamos próximos ao sensor, senão, afastados.
    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.values[0] == 0)
        {
            getWindow().getDecorView().setBackgroundColor(Color.LTGRAY);
            resposta.setText("Está PRÓXIMO");
        }
        else{
            getWindow().getDecorView().setBackgroundColor(Color.CYAN);
            resposta.setText("AFASTADO");
        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}