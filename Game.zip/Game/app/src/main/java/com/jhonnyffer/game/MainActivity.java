package com.jhonnyffer.game;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    ImageView btnPlay1, btnPlay2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnPlay1 = findViewById(R.id.btnPlay1);
        btnPlay2 = findViewById(R.id.btnPlay2);
    }

    public void onClick(View view){
        switch (view.getId()){
            case R.id.btnPlay1:
                Intent janelaV = new Intent(this, JogoVelha.class);
                startActivity(janelaV);
                break;

            case R.id.btnPlay2:
                Intent janelaQ = new Intent(this, Puzzle.class);
                startActivity(janelaQ);
                break;
        }
    }
}